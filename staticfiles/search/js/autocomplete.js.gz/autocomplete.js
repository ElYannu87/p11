  

/
$(".product-input").autocomplete({
    source: autocomplete_url,
    minLength: 3,
    classes : {"ui-autocomplete": "autocomplete-rectangle"}
});